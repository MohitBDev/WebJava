package com.app.service;

import java.util.List;

import com.app.entities.Department;
import com.app.entities.Employee;

public interface DepartmentService {
	List<Department> getalldept();

	
	
	

}
